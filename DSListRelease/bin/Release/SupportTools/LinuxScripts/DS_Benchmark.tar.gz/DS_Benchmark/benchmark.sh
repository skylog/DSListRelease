#!/bin/bash

while :
do
        WHO=`sudo whoami`
        if [ "$WHO" = "root" ];
        then
                break
        else
                echo -e "\nPlease try again\n"
        fi
done

######### copy libs ########
if [ ! -e "/lib/i386-linux-gnu/libaio.so.1.0.1" ]; then
	echo "copy libaio.so.1.0.1"
	sudo cp libs/libaio.so.1.0.1 /lib/i386-linux-gnu/
fi

if [ ! -e "/lib/i386-linux-gnu/libaio.so.1" ]; then
        echo "symlink libaio.so.1"
        sudo ln -s /lib/i386-linux-gnu/libaio.so.1.0.1 /lib/i386-linux-gnu/libaio.so.1
fi

if [ ! -e "/usr/lib/i386-linux-gnu/libaio.so" ]; then
        echo "symlink libaio.so"
        sudo ln -s /lib/i386-linux-gnu/libaio.so.1.0.1 /usr/lib/i386-linux-gnu/libaio.so
fi

######### Zeroing logs #######
echo "" > logs/compress7zip.log
echo "" > logs/aio-stress.log
echo "" > logs/stream.log
echo "" > logs/seeker.log

######### LiveCD or not to LiveCD #########
if [ -f "/home/mint/Desktop/ubiquity-gtkui.desktop" ]; then
	LIVECD="1"
else
	LIVECD="0"
fi

if [ "$LIVECD" == "1" ]; then
	HDD=`sudo fdisk -l | grep "/dev/" | grep -v "Disk" | sed -e 's/*//' | grep -v "swap" | grep "Linux\|NTFS\|FAT32" | awk '{ print $4" "$1 }' | sort -nr | head -n 1 | awk '{ print $2 }'`
	MNT=`df -h | grep "/mnt/bench"`
	if [ "$MNT" == "" ]; then
	        sudo mkdir -p /mnt/bench
	        sudo mount $HDD /mnt/bench
	else
	        echo "mount point is busy"
	        sudo umount /mnt/bench
	        sleep 5
	        sudo mount $HDD /mnt/bench
	fi
else
	HDD=`df -h | grep " /$" | awk '{print $1}' | sed -r 's/[0-9]{1}//'`
	sudo mkdir -p /mnt/bench
fi

######### IO test ############
END=5; i=1; while [ $i -le $END ]; do
        sudo seeker/seeker $HDD >> logs/seeker.log
        i=$(($i+1))
done

######### Disk bench #########
END=3; i=1; while [ $i -le $END ]; do
        sudo aio-stress-1.1.1/aio-stress-bin -O -u -s 2048 -o 0 -o 1 -o 2 -o 3 /mnt/bench/file &>> logs/aio-stress.log
        i=$(($i+1))
done

######### CPU bench ##########
p7zip_9.20.1/bin/7za b > logs/compress7zip.log

######### RAM bench ##########
END=20; i=1; while [ $i -le $END ]; do
	stream-1.2.0/stream-bin >> logs/stream.log
        i=$(($i+1))
done

if [ "$LIVECD" == "1" ]; then
	sudo umount /mnt/bench
	sudo rmdir /mnt/bench
else
	sudo rmdir /mnt/bench
fi

CPU=`cat logs/compress7zip.log | grep "Avr:" | awk '{print $4}'`
IOF=`cat logs/seeker.log | grep "Results:" | awk '{print $2}' | awk '{sum+=$1} END { print sum/NR }'`
IO=`LANG="en_US.utf8" printf '%.0f' $IOF`
DISKRWF=`cat logs/aio-stress.log | grep "random write totals" | sed -e 's/(//' | sed -e 's/)//' | awk '{print $6}' | awk '{sum+=$1} END { print sum/NR }'`
DISKRRF=`cat logs/aio-stress.log | grep "random read totals" | sed -e 's/(//' | sed -e 's/)//' | awk '{print $6}' | awk '{sum+=$1} END { print sum/NR }'`
DISKWF=`cat logs/aio-stress.log | grep "write totals" | grep -v "random" | sed -e 's/(//' | sed -e 's/)//' | awk '{print $5}' | awk '{sum+=$1} END { print sum/NR }'`
DISKRF=`cat logs/aio-stress.log | grep "read totals" | grep -v "random" | sed -e 's/(//' | sed -e 's/)//' | awk '{print $5}' | awk '{sum+=$1} END { print sum/NR }'`
DISKRW=`LANG="en_US.utf8" printf '%.0f' $DISKRWF`
DISKRR=`LANG="en_US.utf8" printf '%.0f' $DISKRRF`
DISKW=`LANG="en_US.utf8" printf '%.0f' $DISKWF`
DISKR=`LANG="en_US.utf8" printf '%.0f' $DISKRF`
RAMCOPYF=`cat logs/stream.log | grep "Copy:" | awk '{print $2}' | awk '{sum+=$1} END { print sum/NR }'`
RAMSCALEF=`cat logs/stream.log | grep "Scale:" | awk '{print $2}' | awk '{sum+=$1} END { print sum/NR }'`
RAMADDF=`cat logs/stream.log | grep "Add:" | awk '{print $2}' | awk '{sum+=$1} END { print sum/NR }'`
RAMTRIADF=`cat logs/stream.log | grep "Triad:" | awk '{print $2}' | awk '{sum+=$1} END { print sum/NR }'`
RAMCOPY=`LANG="en_US.utf8" printf '%.0f' $RAMCOPYF`
RAMSCALE=`LANG="en_US.utf8" printf '%.0f' $RAMSCALEF`
RAMADD=`LANG="en_US.utf8" printf '%.0f' $RAMADDF`
RAMTRIAD=`LANG="en_US.utf8" printf '%.0f' $RAMTRIADF`
RAMAVGF=`echo "$RAMCOPY $RAMSCALE $RAMADD $RAMTRIAD" | awk '{print ($1+$2+$3+$4)/4}'`
RAMAVG=`LANG="en_US.utf8" printf '%.0f' $RAMAVGF`

echo "CPU - $CPU MIPS"
echo "IO - $IO p/s"
echo "Disk write - $DISKW Mb/s"
echo "Disk read - $DISKR Mb/s"
echo "Disk random write - $DISKRW Mb/s"
echo "Disk random read - $DISKRR Mb/s"
echo "RAM Copy - $RAMCOPY Mb/s"
echo "RAM Scale - $RAMSCALE Mb/s"
echo "RAM Add - $RAMADD Mb/s"
echo "RAM Triad - $RAMTRIAD Mb/s"
echo "RAM Avg - $RAMAVG Mb/s"
echo ""

######### CPU INDEX ###########
if [ "$CPU" -le "4000" ];then
	CPUINDEX="2"
elif [ "$CPU" -le 4400 ];then
	CPUINDEX="3"
elif [ "$CPU" -le 4800 ];then
	CPUINDEX="4"
elif [ "$CPU" -le 5200 ];then
	CPUINDEX="5"
elif [ "$CPU" -le 5600 ];then
        CPUINDEX="6"
elif [ "$CPU" -le 6000 ];then
        CPUINDEX="7"
elif [ "$CPU" -le 6400 ];then
        CPUINDEX="8"
elif [ "$CPU" -le 6800 ];then
	CPUINDEX="9"
elif [ "$CPU" -ge 6801 ];then
	CPUINDEX="10"
else
	CPUINDEX="CPU Error"
fi

######## Disk IO INDEX #######
if [ "$IO" -le "20" ];then
	IOINDEX="1"
elif [ "$IO" -le "30" ]; then
	IOINDEX="2"
elif [ "$IO" -le "40" ]; then
        IOINDEX="3"
elif [ "$IO" -le "50" ]; then
        IOINDEX="4"
elif [ "$IO" -le "60" ]; then
        IOINDEX="5"
elif [ "$IO" -le "70" ]; then
        IOINDEX="6"
elif [ "$IO" -le "80" ]; then
        IOINDEX="7"
elif [ "$IO" -le "90" ]; then
        IOINDEX="8"
elif [ "$IO" -le "100" ]; then
        IOINDEX="9"
elif [ "$IO" -ge "101" ]; then
        IOINDEX="10"
else
	IOINDEX="IO Error"
fi

######### Disk write INDEX ######
if [ "$DISKW" -le "70" ]; then
	DISKWINDEX="1"
elif [ "$DISKW" -le "80" ]; then
	DISKWINDEX="2"
elif [ "$DISKW" -le "100" ]; then
        DISKWINDEX="3"
elif [ "$DISKW" -le "120" ]; then
        DISKWINDEX="4"
elif [ "$DISKW" -le "140" ]; then
        DISKWINDEX="5"
elif [ "$DISKW" -le "160" ]; then
        DISKWINDEX="6"
elif [ "$DISKW" -le "180" ]; then
        DISKWINDEX="7"
elif [ "$DISKW" -le "200" ]; then
        DISKWINDEX="8"
elif [ "$DISKW" -le "220" ]; then
        DISKWINDEX="9"
elif [ "$DISKW" -ge "221" ]; then
        DISKWINDEX="10"
else
	DISKWINDEX="DISKWINDEX Error"
fi

######### Disk read INDEX ######
if [ "$DISKR" -le "70" ]; then
        DISKRINDEX="1"
elif [ "$DISKR" -le "80" ]; then
        DISKRINDEX="2"
elif [ "$DISKR" -le "100" ]; then
        DISKRINDEX="3"
elif [ "$DISKR" -le "120" ]; then
        DISKRINDEX="4"
elif [ "$DISKR" -le "140" ]; then
        DISKRINDEX="5"
elif [ "$DISKR" -le "160" ]; then
        DISKRINDEX="6"
elif [ "$DISKR" -le "180" ]; then
        DISKRINDEX="7"
elif [ "$DISKR" -le "200" ]; then
        DISKRINDEX="8"
elif [ "$DISKR" -le "220" ]; then
        DISKRINDEX="9"
elif [ "$DISKR" -ge "221" ]; then
        DISKRINDEX="10"
else
        DISKRINDEX="DISKRINDEX Error"
fi

######### Disk random write index #####
if [ "$DISKRW" -le "4" ]; then
        DISKRWINDEX="1"
elif [ "$DISKRW" -le "5" ]; then
        DISKRWINDEX="2"
elif [ "$DISKRW" -le "6" ]; then
        DISKRWINDEX="3"
elif [ "$DISKRW" -le "7" ]; then
        DISKRWINDEX="4"
elif [ "$DISKRW" -le "8" ]; then
        DISKRWINDEX="5"
elif [ "$DISKRW" -le "9" ]; then
        DISKRWINDEX="6"
elif [ "$DISKRW" -le "10" ]; then
        DISKRWINDEX="7"
elif [ "$DISKRW" -le "11" ]; then
        DISKRWINDEX="8"
elif [ "$DISKRW" -le "12" ]; then
        DISKRWINDEX="9"
elif [ "$DISKRW" -ge "13" ]; then
        DISKRWINDEX="10"
else
        DISKRWINDEX="DISKRWINDEX Error"
fi

######### Disk random read index #####
if [ "$DISKRR" -le "8" ]; then
        DISKRRINDEX="1"
elif [ "$DISKRR" -le "10" ]; then
        DISKRRINDEX="2"
elif [ "$DISKRR" -le "12" ]; then
        DISKRRINDEX="3"
elif [ "$DISKRR" -le "14" ]; then
        DISKRRINDEX="4"
elif [ "$DISKRR" -le "16" ]; then
        DISKRRINDEX="5"
elif [ "$DISKRR" -le "18" ]; then
        DISKRRINDEX="6"
elif [ "$DISKRR" -le "20" ]; then
        DISKRRINDEX="7"
elif [ "$DISKRR" -le "22" ]; then
        DISKRRINDEX="8"
elif [ "$DISKRR" -le "24" ]; then
        DISKRRINDEX="9"
elif [ "$DISKRR" -ge "25" ]; then
        DISKRRINDEX="10"
else
        DISKRRINDEX="DISKRRINDEX Error"
fi

####### RAM index ######
if [ "$RAMAVG" -le "5000" ]; then
	RAMINDEX="1"
elif [ "$RAMAVG" -le "5000" ]; then
        RAMINDEX="2"
elif [ "$RAMAVG" -le "5500" ]; then
        RAMINDEX="3"
elif [ "$RAMAVG" -le "6000" ]; then
        RAMINDEX="4"
elif [ "$RAMAVG" -le "6500" ]; then
        RAMINDEX="5"
elif [ "$RAMAVG" -le "7000" ]; then
        RAMINDEX="6"
elif [ "$RAMAVG" -le "7500" ]; then
        RAMINDEX="7"
elif [ "$RAMAVG" -le "8000" ]; then
        RAMINDEX="8"
elif [ "$RAMAVG" -le "8500" ]; then
        RAMINDEX="9"
elif [ "$RAMAVG" -ge "8501" ]; then
        RAMINDEX="10"
else
	RAMINDEX="RAM Error"
fi

echo "CPU INDEX - $CPUINDEX"
echo "IO INDEX - $IOINDEX"
echo "DISK W INDEX - $DISKWINDEX"
echo "DISK R INDEX - $DISKRINDEX"
echo "DISK RW INDEX - $DISKRWINDEX"
echo "DISK RR INDEX - $DISKRRINDEX"
echo "RAM INDEX - $RAMINDEX"
echo ""
RESULT=`echo -e "$CPUINDEX\n$IOINDEX\n$DISKWINDEX\n$DISKRINDEX\n$DISKRWINDEX\n$DISKRRINDEX\n$RAMINDEX" | sort -n | head -n 1`
echo "Result - $RESULT"
